
# Midnight EPOS — Full Stack v2 (Domain Engine + Drizzle + Outbox)

This pack includes:
- **packages/domain** (the brain): use-cases, ports, events, schemas
- **apps/server**: Express + Drizzle repos (Orders/Products/Customers), Outbox, Invoice PDF route (Puppeteer), Engine wiring
- **apps/web**: Midnight-styled Vite starter (Sales/Inventory/Reports/Login), barcode hook, templates
- **CI guards**: fails build if code uses 'item' instead of **OrderLine**
- **Agent Task List**: step-by-step build with tests re-run at each phase

## Quick Start (Dev)
```bash
# 1) Web
cd apps/web
npm i
npm run dev

# 2) Server
cd ../server
npm i
npm run dev

# 3) Run tests
npm run test:integration
```

## Naming guard (CI/local)
```bash
bash ./scripts/guard-naming.sh
```


## Agent Quickstart (Zero manual steps)
Run:
```bash
npm run agent:start
```
This installs all workspaces, builds the domain package, and starts the server in **in-memory mode** (no database required).

To run tests + naming guard:
```bash
npm run agent:test
```

To switch to Postgres later, set `DATABASE_URL` in the environment before starting.


## Analytics Worker
Run the background worker to consume `domain_outbox` and project analytics:

```bash
npm -w @midnight/server run worker
```

It processes new outbox entries (e.g., `OrderAggregatesRequested`) and will later update daily/weekly/monthly aggregates and RFM/CLV metrics.


## Analytics Tables
The system now includes:
- `analytics_daily` (date, orders, revenue)
- `analytics_weekly` (year, week, orders, revenue)
- `analytics_monthly` (year, month, orders, revenue)
- `customer_metrics` (per customer RFM/CLV fields)

### Usage
1. Start server with DATABASE_URL set
2. Place some orders → events go into domain_outbox
3. Run worker:
```bash
npm -w @midnight/server run worker
```
4. Query aggregates:
```sql
SELECT * FROM analytics_daily ORDER BY date DESC;
SELECT * FROM customer_metrics WHERE customer_id = '...';
```


### RFM & CLV
- **rfm_score**: composite of Recency (1–5), Frequency (1–5), Monetary (1–5). Max 15.
- **clv**: rough lifetime value estimate based on avg order value × purchase frequency × 3 years.

Example query:
```sql
SELECT customer_id, order_count, total_spent, rfm_score, clv
FROM customer_metrics
ORDER BY clv DESC;
```


## Analytics API Endpoints
- **GET /api/analytics/top-customers?limit=5** → top N customers by CLV  
- **GET /api/analytics/daily-revenue** → last 30 days revenue & order counts  
- **GET /api/analytics/monthly-summary** → last 12 months revenue & order counts  


## Frontend Dashboard
- Visit `/` in the web app → **Analytics Dashboard**
- Shows:
  - Top customers (table with RFM + CLV)
  - Daily revenue (line chart)
  - Monthly orders (bar chart)


## Authentication
- Backend `requireAuth` checks for `x-replit-user-id` header (bypass if NODE_ENV=development).
- `/api/auth/session` returns `{ user }` if logged in, otherwise 401.
- Frontend `AuthGate` component protects the Analytics Dashboard.


## Login Flow
- Visit dashboard → if not logged in, shows **Login with Replit** button.
- Button calls `/api/auth/login`:
  - In dev: returns fake user JSON (`dev-user`).
  - In prod: redirects to Replit login (OIDC).


## OAuth Callback
- `/api/auth/login` → Replit OAuth (stubbed to Replit login page)
- `/api/auth/callback` → handles OAuth return
  - Dev: sets fake session user
  - Prod: (TODO) exchange `code` for token via Replit OIDC and store session user
- `/api/auth/session` → returns current user if logged in


## Session Storage
- Uses `express-session` with `connect-pg-simple` to persist sessions in Postgres (`user_sessions` table).
- Cookie is HTTP-only, `secure` in production, `sameSite=lax`, maxAge = 7 days.
- Migration file: `apps/server/src/db/migrations/000_session_table.sql` creates the session table.


## Logout
- **POST /api/auth/logout** → clears session and cookie.
- Frontend shows a **Logout** button in the dashboard header.


## Testing
- Backend unit tests: `jest --config jest.server.config.js`
- Backend integration tests (APIs): `jest --config jest.server.config.js`
- Frontend tests: `jest --config jest.web.config.js`

The suite checks:
- Business logic (profit, loyalty)
- API endpoints (analytics + auth cycle)
- Frontend rendering of Analytics Dashboard
